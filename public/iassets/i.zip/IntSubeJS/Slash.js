﻿function slasher() {
    var slasher = 1;
}