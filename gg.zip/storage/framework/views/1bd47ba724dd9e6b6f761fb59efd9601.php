
<?php $__env->startSection('content'); ?>
    <div class="container-xl">
        <div class="row row-cards">
            <div class="col-12">
                <form action="<?php echo e(route('options.store')); ?>" method="post" class="card" enctype="multipart/form-data">
                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" />
                    <div class="card-header">
                        <h4 class="card-title">Site Ayarları</h4>

                    </div>
                    <div class="card-body">
                        <div class="row g-5">
                            <div class="col-xl-12">
                                <div class="row">

                                    <div class="col-md-6 col-xl-12">
                                        <input type="hidden" name="csrf_token" value="<?php echo e(csrf_token()); ?>" />
                                        <?php echo method_field('POST'); ?>
                                        <div class="row">
                                            <?php $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="col-md-4">
                                                    <div class="form-group mb-3">
                                                        <label for="key" class="mb-2"><?php echo e($option->key); ?></label>
                                                        <input type="hidden" name="option[<?php echo e($option->id); ?>][key]"
                                                            value="<?php echo e($option->key); ?>" />
                                                        <input type="text" class="form-control" id="<?php echo e($option->key); ?>"
                                                            value="<?php echo e($option->value); ?>" name="option[<?php echo e($option->id); ?>][value]">
                                                    </div>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <div class="col-md-12">
                                                <button type="submit" class="btn btn-primary">Submit</button>
                                            </div>

                                        </div>
                                    </div>

                                </div>
                            </div>


                        </div>
                    </div>

                </form>
            </div>


        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\g\resources\views/admin/options.blade.php ENDPATH**/ ?>