
<?php $__env->startSection('content'); ?>
    <div class="container-xl">
        <div class="row row-cards">
            <div class="col-12">
                <form action="<?php echo e(route('options.store')); ?>" method="post" class="card" enctype="multipart/form-data">
                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" />
                    <div class="card-header">
                        <h4 class="card-title">Site Ayarları</h4>

                    </div>
                    <div class="card-body">
                        <div class="row g-5">
                            <div class="col-xl-12">
                                <div class="row">

                                    <div class="col-md-6 col-xl-12">
                                        <input type="hidden" name="csrf_token" value="<?php echo e(csrf_token()); ?>" />
                                        <?php echo method_field('POST'); ?>
                                        <?php
                                            $result = $options->keyBy->key->collect();
                                        ?>

                                        <div class="row">
                                            <div class="col-md-4">
                                                <div class="form-group mb-3">
                                                    <label for="key" class="mb-2">kampanya_link</label>
                                                    <input type="hidden" name="option[kampanya_link][key]"
                                                        value="kampanya_link">
                                                    <input type="text" class="form-control" id="kampanya_link"
                                                        value="<?php echo e($result['kampanya_link']['value']); ?>"
                                                        name="option[kampanya_link][value]">
                                                </div>
                                            </div>

                                            <div class="col-md-4">
                                                <div class="form-group mb-3">
                                                    <label for="key" class="mb-2">yasak_yonlendirme_link</label>
                                                    <input type="hidden" name="option[yasak_yonlendirme_link][key]"
                                                        value="yasak_yonlendirme_link">
                                                    <select name="option[yasak_yonlendirme_link][value]"
                                                        class="form-control">
                                                        <option value="home"
                                                            <?php echo e($result['yasak_yonlendirme_link']['value'] == 'home' ? 'selected' : ''); ?>>
                                                            Anasayfaya Yönlendir</option>
                                                        <option value="404"
                                                            <?php echo e($result['yasak_yonlendirme_link']['value'] == '404' ? 'selected' : ''); ?>>
                                                            404 at</option>
                                                    </select>
                                                </div>
                                            </div>

                                            <div class="col-md-12">
                                                <button type="submit" class="btn btn-primary">Submit</button>
                                            </div>

                                        </div>
                                    </div>

                                </div>
                            </div>


                        </div>
                    </div>

                </form>
            </div>


        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\g\gg\resources\views/admin/options.blade.php ENDPATH**/ ?>